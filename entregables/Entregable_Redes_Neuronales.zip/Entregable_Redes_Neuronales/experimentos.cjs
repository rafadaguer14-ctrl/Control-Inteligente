const {Network,dataset,split}=require('./neural-core.js');
const cases=[
 ['AND sin capa oculta','and',[],.5,3000],
 ['XOR sin capa oculta','xor',[],.5,3000],
 ['XOR cuatro neuronas lineales','xor',[{n:4,activation:'linear'}],.5,3000],
 ['XOR una neurona tanh','xor',[{n:1,activation:'tanh'}],.5,3000],
 ['XOR cuatro neuronas tanh','xor',[{n:4,activation:'tanh'}],.5,3000],
 ...[.01,.1,1].map(rate=>['XOR tasa '+rate,'xor',[{n:4,activation:'tanh'}],rate,1000]),
 ['Circulo ocho neuronas tanh','circle',[{n:8,activation:'tanh'}],.3,2000]
];
const results=cases.map(([name,kind,hidden,rate,epochs])=>{
 const model=new Network(hidden,42),data=split(dataset(kind,42),42);
 for(let i=0;i<epochs;i++)model.step(data.train,rate);
 return {experimento:name,capas:hidden,semilla:42,tasa:rate,epocas:epochs,
  nEntrenamiento:data.train.length,nEvaluacion:data.test.length,
  costeEntrenamiento:model.loss(data.train),aciertoAjuste:model.accuracy(data.train),
  costeEvaluacion:data.test.length?model.loss(data.test):null,
  aciertoEvaluacion:data.test.length?model.accuracy(data.test):null};
});
console.log(JSON.stringify(results,null,2));
