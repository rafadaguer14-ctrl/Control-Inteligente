// Verificación opcional: node verificar.cjs. La interfaz no requiere Node.js.
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const R=require('./regression-core.js');
const d=R.parseCSV(fs.readFileSync(path.join(__dirname,'Temperatura_Colombia_1961_2019.csv'),'utf8'));
assert.deepEqual(d.headers,['anio','cambio_temperatura']);
const X=d.rows.map(r=>[R.numeric(r[0])]),y=d.rows.map(r=>R.numeric(r[1]));
assert.equal(y.length,59);assert(X.every((r,i)=>r[0]===1961+i));assert(y.every(v=>v!==null));
const split=R.split(y.length,.2,42),model=R.fit(split.train.map(i=>X[i]),split.train.map(i=>y[i]));
const score=R.metrics(split.test.map(i=>y[i]),split.test.map(i=>model.predict(X[i])));
const all=R.fit(X,y);
console.log(JSON.stringify({dataset:'Colombia 1961–2019',filas:y.length,entrenamiento:split.train.length,evaluacion:split.test.length,semilla:42,metricasEvaluacion:score,modeloInterfaz:{intercepto:model.intercept,pendiente:model.coefficients[0]},tendenciaDescriptiva59Anios:{intercepto:all.intercept,pendiente:all.coefficients[0],metricasAjuste:R.metrics(y,X.map(x=>all.predict(x)))}},null,2));
// Comprobación independiente de mínimos cuadrados simples.
const mx=X.reduce((s,r)=>s+r[0],0)/X.length,my=y.reduce((s,v)=>s+v,0)/y.length;
const slope=X.reduce((s,r,i)=>s+(r[0]-mx)*(y[i]-my),0)/X.reduce((s,r)=>s+(r[0]-mx)**2,0);
assert(Math.abs(all.coefficients[0]-slope)<1e-10);
